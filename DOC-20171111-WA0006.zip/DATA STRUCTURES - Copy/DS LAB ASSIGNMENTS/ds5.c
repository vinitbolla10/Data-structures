/* Program to accept a list and return a complete copy of that list with one pointer iterating over the original list and two pointers keeping track of the new list */

#include<stdio.h>
#include<malloc.h>

struct node
{
int  info;
struct node *link;
};

/* Declaring variables of type struct node */
struct node *start=NULL,*newnode,*t,*p=NULL;
struct node *head=NULL,*tail=NULL;


/* Function declarations */
void insert(int);
struct node *CopyList(struct node *);
void display(struct node *);


int main()
{
int x;
insert(x);
display(start);
struct node *copy=CopyList(start);
display(head);

return 1;
}

/* Function to insert elements into the list */
void insert(int x)
{
int num,i;
printf("\nEnter number of elements to be inserted: ");
scanf("%d",&num);

for(i=0;i<num;i++)
{
printf("\nEnter element: ");
scanf("%d",&x);

newnode=(struct node*)malloc(sizeof(struct node*));
newnode->info=x;
newnode->link=NULL;
if(start==NULL)
    start=newnode;
else
{
newnode->link=start;
start=newnode;
}
}
}


/* Function to display elements in the list */
void display(struct node *element)
{
if(start==NULL)
   printf("\nLinked list is empty!");
else
{
t=element;
printf("\nDisplaying linked list elements:\n");
while(t!=NULL)
{
printf("%d\n",t->info);
t=t->link;
}
}
}

/* Function to copy original list into a new list */
struct node *CopyList(struct node *)
{
 if(start==NULL)
 {
 printf("\nCannot Copy. Linked list is empty.");
 }
 else
 {
 t=start;
 while(t!=NULL)
 {
 if(head==NULL)
 {
  newnode=(struct node*)malloc(sizeof(struct node*));
  newnode->info=t->info;
  newnode->link=NULL;
  head=newnode;
  tail=newnode;
 }
 else
 {
  newnode=(struct node*)malloc(sizeof(struct node*));
  newnode->info=t->info;
  newnode->link=NULL;
  tail->link=newnode;
  tail=newnode;
 }
 t=t->link;
 }
 }
 return head;
}



/*

*********************************OUTPUT*********************************

// Case I
Enter number of elements to be inserted: 5

Enter element: 56

Enter element: 20

Enter element: 1

Enter element: 23

Enter element: 8

Displaying linked list elements:
8
23
1
20
56

Displaying linked list elements:
8
23
1
20
56

// Case II

Enter number of elements to be inserted: 0

Linked list is empty!
Cannot Copy. Linked list is empty.

*/
