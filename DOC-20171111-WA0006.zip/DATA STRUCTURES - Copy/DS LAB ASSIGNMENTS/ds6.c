/* Program to create a generalized linked list to store multivariable polynomial and performing COPY function on it */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>


struct gll
{
	int tag;
	char data;
	struct gll*link;
	struct gll*nxt;
};


struct gll*start1=NULL;
struct gll*start2=NULL;


//Create
struct gll*create(char a[])
{
	static int i=0;
	struct gll*new=NULL;
	if(a[i]=='\0')
		return NULL;
	for(;a[i]==' '||a[i]==',';i++);
	new = (struct gll*)malloc(sizeof(struct gll));
	if(new==NULL)
	{
		printf("Allocation failed.");
		
		exit(0);
	}
	if(a[i]=='(')
	{
		new->tag=1;
		new->data='(';
		new->nxt=NULL;
		i++;
		new->link=create(a);
	    if(a[i]!='\0'&&a[i]!=',')
		   new->nxt=create(a);
	    else
	    {
		i=0;
	    }
	}
	else if(a[i]!=')')
	{
		new->tag=0;
		new->data=a[i];
		new->link=NULL;
		i++;
		new->nxt=create(a);
	}
	else if(a[i]==')')
	{
		i++;
		free(new);
		return NULL;
	}
	return (new);
} //End of create


/* Function display to display data */
void display(struct gll*ptr1)
{
	if(ptr1==NULL)
		return;
	if(ptr1->tag==1)
	{
		printf("(");
		display(ptr1->link);
		printf(")");
		display(ptr1->nxt);
	}
	else
	{
		printf("%c",ptr1->data);
		display(ptr1->nxt);
	}
} //End of display


/* Function copy to copy the data */
struct gll*copy(struct gll*t)
{
	struct gll*n;
	if(t==NULL)
		return NULL;
	n=(struct gll*)malloc(sizeof(struct gll));
	if(t->tag==1)
	{
		n->tag=1;
		n->data='(';
		n->link=t->link;
		n->nxt=copy(t->nxt);

	}
	else
	{
		n->tag=0;
		n->data=t->data;
		n->link=NULL;
		n->nxt=copy(t->nxt);

	}
	return(n);
} //End of copy


void main()
{
	char str1[20];
	printf("Enter string: \n");
	gets(str1);
	start1=create(str1);
	printf("Created List: \n");
	display(start1);
	start2=copy(start1);
	printf("Copied list: \n");
	display(start2);
	
}

