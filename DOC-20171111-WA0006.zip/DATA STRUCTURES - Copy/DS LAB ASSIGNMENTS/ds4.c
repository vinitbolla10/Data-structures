/* Program to implement double ended queue where user can add and remove elements from both front and rear of the queue */

#include<stdio.h>
#include<stdlib.h>
#define max 5

int deque[max];
int front=-1,rear=-1;	

/* Declaration of functions */		
void display();
void insertfront();
void insertrear();
void deletefront();
void deleterear();


int choice,item;									      	//Declaring variables globally

void main()
{
	
	while(1)
	{
	  printf("\n Menu");
	  printf("\n 1.Insert from Front:");
	  printf("\n 2.Insert from Rear:");
	  printf("\n 3.Delete from Front:");
	  printf("\n 4.Delete from Rear:");
	  printf("\n 5.Display");
	  printf("\n 6.Exit\n");
	  scanf("%d",&choice);
	switch(choice)
	{
	case 1:
	insertfront();
	
	break;

	case 2:
	insertrear();
	
	break;

	case 3:
	deletefront();
	
	break;

	case 4:
	deleterear();
	
	break;

	case 5:
	display();
	
	break;

	case 6:
	exit(0);

	default:
	printf("\n Invalid Choice\n");
	
	break;
	}
	}
}


/* Function to insert element from front */
void insertfront()
{
	if(front==0)
	{
	 printf("\n Queue is FULL");
	}
	
	else if(front==-1)
	 {
		front=rear=0;
		printf("\n Enter a no:");
		scanf("%d",&item);
		deque[front]=item;
	 }
	 
	 else
	 {
	  front=front-1;
	  printf("\n Enter a no:");
	  scanf("%d",&item);
	  deque[front]=item;
	  }
}

/* Function to insert element from rear */
void insertrear()
{
	if(rear==max)
	{
	 printf("\n Queue is FULL");
	}
	else
	{
	 rear=rear+1;
	 printf("\n Enter a no.:");
	 scanf("%d",&item);
	 deque[rear]=item;
	}
}

/* Function to delete element from front */
void deletefront()
{
	if(front==max)
	{
	  printf("\n Queue is EMPTY");
	}
	else
	{
	 item=deque[front];
	 front=front+1;
	 printf("\n No. deleted is %d\n",item);
	}
}

/* Function to delete element from rear */
void deleterear()
{
	if(rear==0)
	{
	  printf("\n Queue is EMPTY\n");
	}
	else
	{
	 item=deque[rear];
	 rear=rear-1;
	 printf("\n No. deleted is %d\n",item);
	}
}

/* Function to display elements in the queue */
void display()
{
int i;
printf("\n The Queue is::\n");
for(i=front;i<=rear;i++)
{
  printf("%d \n ", deque[i]);
}
}


/*

*********************************OUTPUT***********************************


 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
1

 Enter a no:60

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
2

 Enter a no.:45

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
2

 Enter a no.:33

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
2

 Enter a no.:20

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
2

 Enter a no.:90

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
2

 Enter a no.:78

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
2

 Queue is FULL
 
 
 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
5

 The Queue is::
60 
 45 
 33 
 20 
 90 
 78 
 
 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
3

 No. deleted is 60

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
3

 No. deleted is 45

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
4

 No. deleted is 78

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
4

 No. deleted is 90

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
4

 No. deleted is 20

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
3

 No. deleted is 33

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
4

 No. deleted is 33

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
4

 No. deleted is 45

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
4

 Queue is EMPTY


 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
5

 The Queue is::

 Menu
 1.Insert from Front:
 2.Insert from Rear:
 3.Delete from Front:
 4.Delete from Rear:
 5.Display
 6.Exit
6

*/
