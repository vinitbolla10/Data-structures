/* Program to create a binary tree and perform Inorder and Preorder traversal on it. Also to find height of the tree and display maximum */

#include<stdio.h>
#include<malloc.h>
#define min -65535

typedef struct binarytree
{
	int data,flag;
	struct binarytree *left,*right;
} node;


node *create(node *r,int d)
{
 if(r == NULL)
 {
  r = (node *)malloc(sizeof(node));
  r->data = d;
  r->left = r->right = NULL;
 }
 else
 {
  if(r->data <= d)
   r->right = create(r->right,d);
  else
   r->left = create(r->left,d);
  }
 return r;
 }

/* Function to find height of the tree */
int height(node* node)
{
   if (node==NULL)
       return 0;
   else
   {
       
       int left_depth = height(node->left);
       int right_depth = height(node->right);

       if (left_depth > right_depth)
	   return(left_depth+1);
       else return(right_depth+1);
   }
}


/* Function to find maximum */
int maximum(node * root)
{
    
    int root_val;
    int left, right;
    int max = min;

    if(root != NULL)
    {

	root_val = root -> data;

	left = maximum(root -> left);
	
	right = maximum(root -> right);
	
	if(left > right)
	    max = left;
	else
	    max = right;

	if(root_val > max)
	    max = root_val;
    }

    return max;
}

/* Function for Inorder traversal */
void inorder(node *r)
 {
 int top=0;
 node *s[20],*pt=r;
 s[0]=NULL;
 while(pt != NULL)
  {
  s[++top] = pt;
  pt = pt->left;
  }
 pt = s[top--];
 while(pt != NULL)
  {
  printf("%d\t",pt->data);
  if(pt->right != NULL)
   {
   pt = pt->right;
   while(pt != NULL)
    {
    s[++top] = pt;
    pt = pt->left;
    }
   }
   pt = s[top--];
  }
 }

/* Function for Preorder traversal */
void preorder(node *r)
 {
 int top=0;
 node *s[20],*pt=r;
 s[0]=NULL;
 while(pt != NULL)
  {
  printf("%d\t",pt->data);
  if(pt->right != NULL)
   s[++top] = pt->right;
  if(pt->left != NULL)
   pt = pt->left;
  else
   pt = s[top--];
  }
 }



int main()
{
 int d,ch,choice;

 node *head = NULL;
  do
    {
    printf("1.Insert\n2.Inorder traversal\n3.Preorder traversal\n4.Maximum\n5.Display height\n");
    printf("Enter choice: ");
    scanf("%d",&ch);
    switch(ch)
    {
    case 1:
 printf("\n Enter the item to insert: ");
  scanf("%d",&d);
  head = create(head,d);
 break;
 case 2:
 inorder(head);
break;
case 3:
 preorder(head);
 break;
 case 4:
printf("\nMaximum= %d",maximum(head));
break;
case 5:
printf("\nHeight= %d",height(head));
break;
 }
 printf("Press 1 to continue: ");
 scanf("%d",&choice);
 }while(choice==1);

return 0;
}



/*
*************************************************OUTPUT**********************************************************

1.Insert
2.Inorder traversal
3.Preorder traversal
4.max
5.Display height
Enter choice: 1

 Enter the item to insert: 20
Press 1 to continue: 1
1.Insert
2.Inorder traversal
3.Preorder traversal
4.max
5.Display height
Enter choice: 1

 Enter the item to insert: 1
Press 1 to continue: 1
1.Insert
2.Inorder traversal
3.Preorder traversal
4.max
5.Display height
Enter choice: 1

 Enter the item to insert: 23
Press 1 to continue: 1
1.Insert
2.Inorder traversal
3.Preorder traversal
4.max
5.Display height
Enter choice: 1

 Enter the item to insert: 7
Press 1 to continue: 1
1.Insert
2.Inorder traversal
3.Preorder traversal
4.max
5.Display height
Enter choice: 1

 Enter the item to insert: 80
Press 1 to continue: 1
1.Insert
2.Inorder traversal
3.Preorder traversal
4.max
5.Display height
Enter choice: 1

 Enter the item to insert: 34
Press 1 to continue: 1
1.Insert
2.Inorder traversal
3.Preorder traversal
4.max
5.Display height
Enter choice: 2
1	7	20	23	34	80	Press 1 to continue: 1
1.Insert
2.Inorder traversal
3.Preorder traversal
4.max
5.Display height
Enter choice: 3
20	1	7	23	80	34	Press 1 to continue: 1
1.Insert
2.Inorder traversal
3.Preorder traversal
4.max
5.Display height
Enter choice: 4
Press 1 to continue: 1
1.Insert
2.Inorder traversal
3.Preorder traversal
4.Maximum
5.Display height
Enter choice: 4

Maximum= 80Press 1 to continue: 1
1.Insert
2.Inorder traversal
3.Preorder traversal
4.Maximum
5.Display height
Enter choice: 5

Height= 4Press 1 to continue: 0

*/
