/* Program to convert given Prefix expression to Postfix expression and evaluating using stack */

#define size 50
#include<stdio.h>
#include <string.h>
#include <ctype.h>

char operands[50][80],operators[50];
int  top_opr=-1,top_opd=-1;
int s[size];
int top=-1;

push_opd(char *opd)
{
    strcpy(operands[++top_opd],opd);
}
char *pop_opd()
{
    return(operands[top_opd--]);
}

push_opr(char opr)
{
    operators[++top_opr]=opr;
}

char pop_opr()
{
    return(operators[top_opr--]);
}

int empty(int t)
{
    if( t == 0) return(1);
    return(0);
}

/* Push function used to push element in the stack */
push(int element)
{                       		
    s[++top]=element;
}

/* Pop function for popping element out of stack */
int pop()
{                      
    return(s[top--]);
}

void evaluate(char *);

main()
{
  
    char prefix[50],ch,str[50],opnd1[50],opnd2[50],opr[2];
    int i=0,k=0,opd_count=0;
    printf("Enter a Prefix Expression: ");
    gets(prefix);
    
    while( (ch=prefix[i++]) != '\0')
    {
	if(isalnum(ch))
	{
	    str[0]=ch; str[1]='\0';
	    push_opd(str); opd_count++;
	    if(opd_count >= 2)
	    {
		strcpy(opnd2,pop_opd());
		strcpy(opnd1,pop_opd());
		strcpy(str,opnd1);
		strcat(str,opnd2);
		ch=pop_opr();
		opr[0]=ch;opr[1]='\0';
		strcat(str,opr);
		push_opd(str);
		opd_count-=1;
	    }
	}
	else
	{
	    push_opr(ch);
	    if(opd_count==1)opd_count=0;         			/* operator followed by single operand*/
	}
    }
    if(!empty(top_opd))
    {
	strcpy(opnd2,pop_opd());
	strcpy(opnd1,pop_opd());
	strcpy(str,opnd1);
	strcat(str,opnd2);
	ch=pop_opr();
	opr[0]=ch;opr[1]='\0';
	strcat(str,opr);
	push_opd(str);
    }
    printf("\nRequired Postfix Expression: ");
    puts(operands[top_opd]);

   operands[top_opd];

   evaluate(operands[top_opd]);

}

/* Function to evaluate given Prefix expression into Postfix expression */
void evaluate(char postfix[])
{
char ch,ch1='0';
    int i=0,operand1,operand2;
    while( (ch=postfix[i++]) != '\0')
    {
	if(isdigit(ch)) push(ch-'0'); 					/* Pushing the operand into the stack */
	else
	{        										
	    operand2=pop();								/* Popping two operands to perform operation with operator */
	    operand1=pop();
	    switch(ch)
	    {
	    case '+':push(operand1+operand2);break;
	    case '-':push(operand1-operand2);break;
	    case '*':push(operand1*operand2);break;
	    case '/':push(operand1/operand2);break;
	    }
	}
    }
    printf("\nValue of expression after evaluation: %d\n",s[top]);
}








/*
******************************************OUTPUT***************************************
Enter a Prefix Expression: -*-535/72                  

Required Postfix Expression: 53-5*72/-

Value of expression after evaluation: 7

*/