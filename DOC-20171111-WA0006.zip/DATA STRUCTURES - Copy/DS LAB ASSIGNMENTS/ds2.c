/*Program to simulate faculty database as a hash table and searching a particular faculty by using MOD as a hash function for linear probing with chaining with replacement method of collision handling technique*/

#include<stdio.h>
#include<stdlib.h>

struct faculty												//Declaring structure faculty
{
 char *name;
 int id;
 int index;
} hash[10],f[10];

int func_key(int);											//Declaring function func_key
void insert(struct faculty,int);							//Declaring function Insert
void search();												//Declaring function Search
void display(struct faculty []);							//Declaring function Display
void chain(int,int,int,struct faculty);						//Declaring function Chain

int main()
{
 int i,ch,key,n;
 

for(i=0;i<10;i++)
 {
  hash[i].name="NULL";
  hash[i].id=-1;
  hash[i].index=-1;
 }


do
	  {
	   printf("\nPress 1 to insert record. \nPress 2 to search for a record. \nPress 3 to display a record.\nPress 4 to quit\n");
	   scanf("%d",&ch);

	   switch(ch)
	   {
		case 1: printf("\nEnter number of records to be inserted.\n");
				scanf("%d",&n);

				for(i=0;i<n;i++)
				{
				 printf("\nEnter faculty name and id.\n");
				 scanf("%s %d",&f[i].name,&f[i].id);

				key=func_key(f[i].id);
				insert(f[i],key);
				}

				break;

		case 2: search();

				break;

		case 3: display(hash);


			break;
			}

	   } while(ch!=4);
}

/* Function to calculate key for hash table */
int func_key(int x)
{
int key=x%10;
return key;
}


/* Function to insert faculty data into the hash table */
void insert(struct faculty t,int key)
{
 struct faculty temp;
 int flag=0,i,count=0;
 if(hash[key].id==-1)
 {
  hash[key].name=t.name;
  hash[key].id=t.id;
 }
 else
 {
  i=0;
  while(i<10)
  {
   if(hash[i].id!=-1)
   count++;

   i++;
  }
  if(count==10)
  {
   printf("\nHash table full. Number cannot be inserted.");
  }

  i=key;
  if(hash[key].id%10==i)
  {
   chain(i,key,flag,t);
  }
  else
  {
   temp=hash[i];
   hash[i]=f[key];
   chain(i,key,flag,temp);
  }
}
}

/* Function to search faculty data using faculty ID */
void search()
{
 int id1,t,i,flag=0;
 printf("\nEnter faculty ID. ");
 scanf("%d",&id1);

 for(i=0;i<10;i++)
 {
  if(hash[i].id==id1)
  {
   flag=1;
   t=i;
  }
 }
 if(flag==1)
 {
  printf("\nRecord found at location %d",t+1);
 }
 else
 {
  printf("\nRecord not found.");
 }
}


/* Function to display faculty details stored in the hash table */
void display(struct faculty hash[10])
{
 int i;
 printf("\nFaculty name\t\tFaculty ID");
 for(i=0;i<10;i++)
 {
  printf("\n%s\t\t%d",hash[i].name,hash[i].id);
 }
}

/* Function for collision handling using chaining with replacement in the hash table */
void chain(int i,int key,int flag,struct faculty t)
{
  int j;
  for(i=key+1;i<10;i++)
  {
   if(hash[i].id==-1)
   {
    hash[i].name=t.name;
    hash[i].id=t.id;
    hash[key].index=i;
    flag=1;

    break;
    }
  }
  for(i=0;i<key;i++)
  {
   if(hash[i].id==-1)
   {
    hash[i].name=t.name;
  hash[i].id=t.id;
    flag=1;
    break;
   }
  }

 if(hash[key].index==-1)
 {
  hash[key].index=i;
 }

 else
 {
  j=hash[key].index;
 }

 while(j!=-1)
 {
  if(hash[j].index==-1)
  {
     hash[j].index=i;
     break;
  }

  else
     j=hash[j].index;
 }

}


/*
*************************************OUTPUT*************************************

Press 1 to insert record. 
Press 2 to search for a record. 
Press 3 to display a record.
Press 4 to quit
1

Enter number of records to be inserted.
5

Enter faculty name and id.
Ram
12

Enter faculty name and id.
Rahul
23

Enter faculty name and id.
Anita
22

Enter faculty name and id.
Shyam
68 

Enter faculty name and id.
Rohan
70

Press 1 to insert record. 
Press 2 to search for a record. 
Press 3 to display a record.
Press 4 to quit
2

Enter faculty ID. 22

Record found at location 5
Press 1 to insert record. 
Press 2 to search for a record. 
Press 3 to display a record.
Press 4 to quit
3

Faculty name		Faculty ID
Rohan					70
NULL					-1
Ram						12
Rahul					23
Anita					22
NULL					-1
NULL					-1
NULL					-1
Shyam					68
NULL					-1

Press 1 to insert record. 
Press 2 to search for a record. 
Press 3 to display a record.
Press 4 to quit
4

*/