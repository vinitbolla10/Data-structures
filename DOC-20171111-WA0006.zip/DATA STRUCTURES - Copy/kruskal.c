    #include<stdio.h>
    #include<stdlib.h>
    int i,j,k,x,y,q,r,n,ne=1;
    int min_cost,minimum_cost=0,cost_matrix[9][9],parent[9];
    int fnd(int);
    int unii(int,int);
    void main()
    {
    	printf("\nEnter no. of vertices:");
    	scanf("%d",&n);
    	printf("\nEnter the cost adjacency matrix:\n");
    	for(i=1;i<=n;i++)
    	{
    		for(j=1;j<=n;j++)
    		{
    			scanf("%d",&cost_matrix[i][j]);
    			if(cost_matrix[i][j]==0)
    				cost_matrix[i][j]=999;
    		}
    	}
    	printf("The edges of Minimum cost Spanning Tree are\n");
    	while(ne < n)
    	{
    		for(i=1,min_cost=999;i<=n;i++)
    		{
    			for(j=1;j <= n;j++)
    			{
    				if(cost_matrix[i][j] < min_cost)
    				{
    					min_cost=cost_matrix[i][j];
    					x=q=i;
    					y=r=j;
    				}
    			}
    		}
    		q=fnd(q);
    		r=fnd(r);
    		if(unii(q,r))
    		{
    			printf("%d edge (%d,%d) =%d\n",ne++,x,y,min_cost);
    			minimum_cost +=min_cost;
    		}
    		cost_matrix[x][y]=cost_matrix[y][x]=999;
    	}
    	printf("\n\tMinimum cost_matrix = %d\n",minimum_cost);
    	getch();
    }
    int fnd(int i)
    {
    	while(parent[i])
    	i=parent[i];
    	return i;
    }
    int unii(int i,int j)
    {
    	if(i!=j)
    	{
    		parent[j]=i;
    		return 1;
    	}
    	return 0;
    }