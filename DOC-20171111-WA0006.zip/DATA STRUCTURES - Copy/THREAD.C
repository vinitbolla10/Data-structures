#include<stdio.h>
#include<stdlib.h>
typedef enum{false,true} boolean;
struct node *create(struct node *root,int);
struct node *inorder_succ(struct node *ptr);
void inorder(struct node *root);
void preorder(struct node *root);
struct node
{
	struct node *left;
	boolean lthread;
	int info;
	struct node *right;
	boolean rthread;
};
void main()
{
	struct node *root=NULL;
	int select,n,num,i=0;
	while(1)
	{
		printf("\n");
		printf("1: To create Threaded Binary Tree\n ");
		printf("2:Inorder Traversal");
		printf("3:Preorder Traversal");
		scanf("%d",&select);
		switch(select)
		{
			case 1:
				printf("Enter The no of elements To be inserted:  \n");
				scanf("%d",&n);
				for(i=0;i<n;i++)
				{
					printf("Enter The Element to be Inserted :");
					scanf("%d",&num);
					root=create(root,num);
				}
				break;
			case 2:
				inorder(root);
				break;
			case 3:
				preorder(root);
				break;

		}
	}
}
struct node *create(struct node *root,int num)
{
	struct node *tmp,*par,*ptr;
	int found=0;
	ptr=root;
	par=NULL;
	while(ptr!=NULL)/*This Loop Check whether The number is already in The tree or not*/
	{
		if(num==ptr->info)
		{
			found=1;
			break;
		}
		par=ptr;
		if(num < ptr->info)
		{
			if(ptr->lthread==false)
				ptr=ptr->left;
			else 
				break;
		}
		if(num > ptr->info)
		{
			if(ptr->rthread==false)
				ptr=ptr->right;
			else
				break;
		}
	}
	if(found)
		printf("Already Exists ");
	else
	{
		tmp=(struct node *)malloc(sizeof(struct node));
		tmp->info=num;
		tmp->lthread=true;
		tmp->rthread=true;
		if(par==NULL)
		{
			root=tmp;
			tmp->left=NULL;
			tmp->right=NULL;
		}
		else if(num < par->info)
		{
			tmp->left=par->left;
			tmp->right=par;
			par->lthread=false;
			par->left=tmp;
		}
		else
		{
			tmp->right=par->right;
			tmp->left=par;
			par->rthread=false;
			par->right=tmp;
		}
	}
	return root;
}
void inorder(struct node *root)
{
	struct node *ptr;
	if(root==NULL)
	{
		printf("EMPTY TREE ");
		return;
	}
	ptr=root;
	while(ptr->lthread==false)
		ptr=ptr->left;
	while(ptr!=NULL)
	{
		printf("\n%d",ptr->info);
		ptr=inorder_succ(ptr);
	}
}
void preorder(struct node *root)
{
	struct node *ptr;
	if(root==NULL)
	{
		printf("Empty Tree");
		return;
	}
	ptr=root;
	while(ptr!=NULL)
	{
		printf("\t%d",ptr->info);
		if(ptr->lthread==false)
			ptr=ptr->left;
		else if(ptr->rthread==false)
			ptr=ptr->right;
		else
		{
			while(ptr!=NULL && ptr->rthread==true)
				ptr=ptr->right;
			if(ptr!=NULL)
				ptr=ptr->right;
		}
			
	}
}
struct node *inorder_succ(struct node *ptr)
{
	if(ptr->rthread==true)
		return(ptr->right);
	else
	{
		ptr=ptr->right;
		while(ptr->lthread==false)
			ptr=ptr->left;
		return ptr;
	}
}
struct node *postorder_succ(struct node *ptr)
{
	if(ptr->rthread==true )
	{	ptr=ptr->right;
		if(ptr->rthread==false)
		{
			while(ptr->rthread=false)
				ptr=ptr->right;
			
		}
		return ptr;
	}
}
