#include <stdio.h>
#include <conio.h>
#include <alloc.h>

enum boolean
{
    false = 0,
    true = 1
} ;

struct node
{
    enum boolean lthread ;
    struct tree *left ;
    int data ;
    struct tree *right ;
    enum boolean rthread ;
    int flag;
    int son;
} ;

struct node *create(struct node *,int);
void inorder(struct node *);
void postorder(struct node *);
struct node *inorder_succ(struct node *);

struct node *tmp,*par,*ptr;

void main()
{
	struct node *root=NULL;
	int ch,n,num,i=0;
	do
	{
		printf("\n");
		printf("1.Insert\n");
		printf("2.Inorder Traversal\n");
		printf("3.Postorder Traversal\n");
		printf("4.Press 0 to exit.\n");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				printf("Enter the number of elements to be inserted: \n");
				scanf("%d",&n);
				for(i=0;i<n;i++)
				{
					printf("Enter the element: ");
					scanf("%d",&num);
					root=create(root,num);
				}
				break;
			case 2:
				inorder(root);
				break;
			case 3:
				postorder(root);
				break;

		}
	} while(ch!=0);
}


struct node *create(struct node *root,int num)
{

	int found=0;
	ptr=root;
	par=NULL;
	while(ptr!=NULL)
	{
		if(num==ptr->data)
		{
			found=1;
			break;
		}
		par=ptr;
		if(num < ptr->data)
		{
			if(ptr->lthread==false)
				ptr=ptr->left;
			else
				break;
		}
		if(num > ptr->data)
		{
			if(ptr->rthread==false)
				ptr=ptr->right;
			else
				break;
		}
	}
	if(found)
		printf("Already Exists ");
	else
	{
		tmp=(struct node *)malloc(sizeof(struct node));
		tmp->data=num;
		tmp->lthread=true;
		tmp->rthread=true;
		if(par==NULL)
		{
			root=tmp;
			tmp->left=NULL;
			tmp->right=NULL;
		}
		else if(num < par->data)
		{
			tmp->left=par->left;
			tmp->right=par;
			par->lthread=false;
			par->left=tmp;
		}
		else
		{
			tmp->right=par->right;
			tmp->left=par;
			par->rthread=false;
			par->right=tmp;
		}
	}
	return root;
}


void inorder(struct node *root)
{
	struct node *ptr;
	if(root==NULL)
	{
		printf("EMPTY TREE ");
		return;
	}
	ptr=root;
	while(ptr->lthread==false)
		ptr=ptr->left;
	while(ptr!=NULL)
	{
		printf("\n%d",ptr->data);
		ptr=inorder_succ(ptr);
	}
}


struct node *inorder_succ(struct node *ptr)
{
	if(ptr->rthread==true)
		return(ptr->right);
	else
	{
		ptr=ptr->right;
		while(ptr->lthread==false)
			ptr=ptr->left;
		return ptr;
	}
}



void postorder(struct node *root)
{
struct node *p=root->left;
p->son=1;
while(p!=root)
{
if(p->lthread!=1 && p->left->flag!=1)
{
p=p->left;
p->son=1;
}
else if(p->rthread!=1 && p->right->flag!=1)
{
p=p->right;
p->son=0;
}
else
{
printf("%d      ",p->data);
p->flag=1;
while(p->rthread!=1)
p=p->right;
p=p->right;
if(p->son==0)
while(p->lthread!=1)
p=p->left;
p=p->left;
}
}
}